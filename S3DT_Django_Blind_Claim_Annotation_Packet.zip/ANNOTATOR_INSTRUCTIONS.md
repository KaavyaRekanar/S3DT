# Blind annotation protocol — Django S³DT projection validation

**Purpose:** Independently describe what historical Django code excerpts support.

1. Give this folder to an annotator who has **not** inspected the S³DT predictions, case labels, or detector output. If possible, use a second annotator and adjudicate disagreements.
2. Read all `source_excerpts/SRC-*.txt` files in their entirety. Work only from the source and the policy-area description. Do **not** search for the historical fix, CVE, detection outcome, or comparison file.
3. For each `gold_annotations.csv` row, identify the security-relevant behaviour of the stated `subject`. Enter **one** `gold_object` from `REFERENCE_ONTOLOGY.csv`. Use `NONE` if the excerpt does not support a claim for that subject, `OTHER` if the behaviour is material but absent from the ontology (explain in `gold_notes`), or `UNRESOLVED` if the excerpt is insufficient or requires external call-chain context. Do **not** infer that a missing check proves a vulnerability.
4. Record `gold_support_lines` as original file lines (examples: `112-119` or `112,116,120`). Use actual numbered lines in the excerpt, not arbitrary new line numbers. Explain uncertainty in `gold_notes`.
5. Add further security-relevant claims that this one-subject-per-unit protocol misses to `additional_security_claims.csv`. These are retained for qualitative omission analysis; they are NOT included in the narrowly scoped claim-level precision/recall until a separate ontology and matching process is defined.
6. Enter `annotator_id` (use an anonymous consistent identifier such as A1). Do not overwrite predicted outputs; these were deliberately not provided.
7. Return the filled `gold_annotations.csv` (and `additional_security_claims.csv`, if used). A separate evaluation phase will unblind the predictions and compute results.

**Scope:** This is a rule-based source-code claim-projection check of all distinct security-relevant functions emitted by the existing Django pilot (not a test of unrestricted LLM extraction from all lifecycle artifact types). It is NOT an independent detector-accuracy evaluation.

**Validity rules:** An unsupported or unverified provenance line is not automatically evidence of a correct claim. Unresolved items are not counted as correct. The report gives denominators and separately discloses exclusions; no numerical accuracy is reported until the reference labels are actually supplied.

**Caution:** The code excerpts show individual method bodies; they may not suffice to determine the complete security consequences of inherited methods, external helpers, or multi-module interactions. Use `UNRESOLVED` rather than guessing.
