Stage B: controlled claim perturbations, reproducing the unmodified 60-row SIC assessment baseline.
Use stage_b_per_error_type.csv and stage_b_by_policy_advisory_states.csv for descriptive decision stability.
Stage B hybrid scores use the unchanged lambda and cutoffs, but DIFFERENT source-fact-only embedding summaries, so cannot be interpreted as the original published detector scores.
Original case-study notebook, historical evidence and SIC parameters were not edited.
