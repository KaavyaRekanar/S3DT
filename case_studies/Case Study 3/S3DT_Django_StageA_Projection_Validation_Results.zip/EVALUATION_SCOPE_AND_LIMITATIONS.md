# Projection validation scope and interpretation

This program does not retrain, tune, or rerun S3DT. Predicted code claims from the pinned Django evaluation are compared only AFTER independent source review. All 135 repeated code-claim observations are collapsed to their distinct code excerpts. Claims emitted by the SIC outcome stage (`risk_stage`, `activity`) are excluded. CIs are descriptive and do not establish cross-project generalisation.

The ontology is restricted to nine named code subjects. Thus, the reported recall is **within the predefined extraction scope**, not recall of all possible security claims in a software project. Additional notes are not included in F1 until independently reconciled under a documented wider ontology.
