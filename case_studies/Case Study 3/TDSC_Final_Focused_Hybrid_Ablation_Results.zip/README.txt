S3DT FINAL FOCUSED ABLATION — INTERPRETATION GUIDE

This is a NEW DIAGNOSTIC EVIDENCE-LOSS ABLATION on the existing source snapshots.
It does NOT overwrite or modify the original S3DT scores, equations or published results.
The C/O/H adapter is source-fact based and NOT the old SIC-verdict mapping.
Pre-fix and fixed reference labels are advisory-anchored proxies; fixes are known future states.
The seven normal commits are source-stability controls only, NOT independent performance labels.
Each seed is a deterministic mask repeat, NOT a new independent software incident.
The semantic channel embeds raw relevant pinned source excerpts + policy expectation ONLY.
Do NOT claim hybrid superiority unless results independently support it.
A positive result establishes at most robustness on four selected historical incidents.
If original thresholds yield no benefit, report this directly. Do not retune post hoc.

Read ablation_per_seed_comparisons.csv for method scores AND coverage.
Read ablation_per_incident_predictions.csv for the actual 4 case pairs.
Read semantic_inputs_audit.csv for the independently inspectable textual inputs.
Read reference_scope_and_provenance.csv for which checkpoints lack oracle labels.
