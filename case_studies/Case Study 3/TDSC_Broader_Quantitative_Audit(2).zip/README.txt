TDSC broader quantitative evaluation — system-level SICs

One fixed Django SIC library applies to every Django checkpoint.
SIC definitions and common risk factors were selected retrospectively; calibration review is outstanding.
The case-study-specific pilot outputs are not used for this batch.
Fix snapshots are reference-only; source evaluation uses only checkpoint-pinned code.
Reference labels must be independently validated for each (checkpoint, SIC).
No accuracy, F1 or confidence intervals should be claimed until the eligibility gates pass.
Score-only comparisons are internal ablations, not external baseline comparisons.
The Requests registry entry needs a separate system-level policy library.
Runtime stage timings are not scaling curves.
