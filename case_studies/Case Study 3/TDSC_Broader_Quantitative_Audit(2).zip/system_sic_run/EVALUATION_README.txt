TDSC S3DT system-level SIC evaluation

The same Django SIC library and factor assignments apply to every history.
The policy collection was selected retrospectively and the numbers have NOT been independently calibrated.
Do not infer accuracy from model predictions or fill ground truth using prediction columns.
Fix snapshots are reference-only, not prospective detector inputs.
SIC absence, unresolved source structures and missing evidence are NOT PASS.
Independent external validation and incident-clustered uncertainty are required for journal claims.
Requests is a separate software system and is not evaluated using Django SICs.
Policy library fingerprint: 679becc840ff150a3f483e988d17c8f9be698cef577f7e982d710f24face5176
