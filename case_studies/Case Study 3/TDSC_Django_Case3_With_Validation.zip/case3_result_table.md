| transition_id                   | sic_outcome   |   D_structured |   D_embed |   D_hybrid | score_only_label   | detector_output             |
|:--------------------------------|:--------------|---------------:|----------:|-----------:|:-------------------|:----------------------------|
| reported_requirement_to_pre_fix | VIOLATION     |           0.85 |  0.318362 |   0.584181 | SUSPECT            | policy-violating drift      |
| pre_fix_to_fix_reference        | SATISFIED     |           0    |  0.066539 |   0.033269 | PASS               | not emitted (SIC satisfied) |
| ordinary_post_fix_01            | SATISFIED     |           0    |  0        |   0        | PASS               | not emitted (SIC satisfied) |
| ordinary_post_fix_02            | SATISFIED     |           0    |  0        |   0        | PASS               | not emitted (SIC satisfied) |
| ordinary_post_fix_03            | SATISFIED     |           0    |  0        |   0        | PASS               | not emitted (SIC satisfied) |
| ordinary_post_fix_04            | SATISFIED     |           0    |  0        |   0        | PASS               | not emitted (SIC satisfied) |
| ordinary_post_fix_05            | SATISFIED     |           0    |  0        |   0        | PASS               | not emitted (SIC satisfied) |
| ordinary_post_fix_06            | SATISFIED     |           0    |  0        |   0        | PASS               | not emitted (SIC satisfied) |
| ordinary_post_fix_07            | SATISFIED     |           0    |  0        |   0        | PASS               | not emitted (SIC satisfied) |