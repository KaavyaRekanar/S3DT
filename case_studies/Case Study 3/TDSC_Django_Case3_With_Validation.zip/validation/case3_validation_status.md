# Django Case Study 3 — validation status

The initial detector result is an **exploratory, post-report SIC assessment**.
It is not evidence that S3DT detected this vulnerability prior to disclosure.

## Evidence gates

- **historical source provenance**: PASS
- **detector does not see later fix**: PASS
- **commit dates checked**: VERIFIED
- **regression tests reproduced**: PASS
- **sic risk parameter independent review**: PENDING
- **pre disclosure detection**: NOT_CLAIMED_POST_REPORT_EVALUATION
- **ordinary nonviolating history controls**: PASS_7_POST_FIX_SIC_SCOPED_CONTROLS
- **claim projection accuracy**: NOT_YET_EVALUATED
- **multi history detection performance**: NOT_YET_EVALUATED
- **runtime scaling**: NOT_YET_EVALUATED

## What remains for the reviewer responses

1. Have SIC risk values independently reviewed; retain an immutable configuration record.
2. Seven post-fix ordinary Git commits now provide a scoped negative-control check; these are not a general false-positive estimate.
3. Evaluate projection accuracy with independently annotated raw artifacts.
4. Run additional independent security histories and report per-class metrics, uncertainty, and runtime scaling.
5. Keep reference fixes and regression tests unavailable to the detector at pre-fix checkpoints.
